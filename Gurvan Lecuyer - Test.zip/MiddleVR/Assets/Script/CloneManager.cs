﻿using UnityEngine;
using System.Collections;

public class CloneManager : MonoBehaviour
{
    public GameObject clone1;
    public GameObject camera1;

    public GameObject clone100;
    public GameObject camera100;

    //Zoom
    private float distMin1;
    private float distMin100;
    private float distMax1;
    private float distMax100;
    private float coeff;

    //Rotation
    private float sensitivity = 0.1f;
    private Vector3 mouseDown;
    private Vector3 mouseMove;
    private Vector3 rotation;

    //Transformation variables
    private Vector3 cam1ToCam100;
    private Vector3 cam100ToCam1;

    private Vector3 scale;

    private Matrix4x4 transformation;


    // Use this for initialization
    void Start()
    {
        //Initialize the position initiale of the little clone
        clone1.transform.position = camera1.transform.position;
        clone1.transform.Translate(-camera1.transform.forward * 0.3f);
        clone1.transform.Translate(camera1.transform.up * 2);

        //Initialize the position initiale of the big clone
        clone100.transform.position = camera100.transform.position;
        clone100.transform.Translate(-camera100.transform.forward * 30);

        //Distance max and min for the little clone
        distMin1 = (clone1.transform.position.z - camera1.transform.position.z);
        distMax1 = distMin1 + 1.5f;
        //Distance max and min for the big clone
        distMin100 = (clone100.transform.position.z - camera100.transform.position.z);
        distMax100 = distMin100 + 1.5f * 100;

        //other variables
        mouseDown = Vector3.zero;
        mouseMove = Vector3.zero;
        rotation = Vector3.zero;

        //Transformation matrix
        scale = Vector3.one;

    }

    // Update is called once per frame
    void Update()
    {
        //Click on little clone
        if (clone1.GetComponent<objectController>().isClicked)
        {
            mouseDown = clone1.GetComponent<objectController>().mouseDown;
            //Rotation for the little clone
            //get the movement
            mouseMove = (Input.mousePosition - mouseDown);
            //make the rotation
            rotation.y = -(mouseMove.x + mouseMove.y) * sensitivity;
            rotation.x = -(mouseMove.y + mouseMove.z) * sensitivity;
            clone1.transform.Rotate(rotation);
            //store the new mouse reference
            mouseDown = Input.mousePosition;

            //NO need for scale for a rotations
            //CLONE100
            //Transformation for the big clone
            clone100.transform.Rotate(rotation);
        }
        //wheel for little clone
        if (clone1.GetComponent<objectController>().mouseOver)
        {
            //handle the mouse wheel for the little clone
            Vector3 translateVec = clone1.transform.position - camera1.transform.position;
            if (Input.GetAxis("Mouse ScrollWheel") < 0)
            {
                Vector3 newPos = clone1.transform.position;
                if ((clone1.transform.position.z - camera1.transform.position.z) > distMin1)
                {
                    translateVec = camera1.transform.forward * Input.GetAxis("Mouse ScrollWheel");
                    clone1.transform.position = newPos + translateVec;

                    //CLONE100
                    //transformation matrix
                    scale = new Vector3(100f, 100f, 100f);
                    transformation = Matrix4x4.Scale(scale);
                    translateVec = transformation * translateVec;
                    //do the translation
                    clone100.transform.position = new Vector3(clone100.transform.position.x, clone100.transform.position.y, clone100.transform.position.z + translateVec.z);
                }
            }
            else if (Input.GetAxis("Mouse ScrollWheel") > 0)
            {
                
                Vector3 newPos = clone1.transform.position;
                if ((clone1.transform.position.z - camera1.transform.position.z) < distMax1)
                {
                    translateVec = camera1.transform.forward * Input.GetAxis("Mouse ScrollWheel");
                    clone1.transform.position = newPos + translateVec;

                    //CLONE100
                    //transformation matrix
                    scale = new Vector3(100f, 100f, 100f);
                    transformation = Matrix4x4.Scale(scale);
                    translateVec = transformation * translateVec;
                    //do the translation
                    clone100.transform.position = new Vector3(clone100.transform.position.x, clone100.transform.position.y, clone100.transform.position.z + translateVec.z);
                }
            }

        }
        //Click on big clone
        if (clone100.GetComponent<objectController>().isClicked)
        {
            mouseDown = clone100.GetComponent<objectController>().mouseDown;
            //Rotation for the big clone
            //get the movement
            mouseMove = (Input.mousePosition - mouseDown);
            //make the rotation
            rotation.y = -(mouseMove.x + mouseMove.y) * sensitivity;
            rotation.x = -(mouseMove.y + mouseMove.z) * sensitivity;
            clone100.transform.Rotate(rotation);
            //store the new mouse reference
            mouseDown = Input.mousePosition;

            //CLONE1
            //Transformation for the little clone
            clone1.transform.Rotate(rotation);
        }
        //wheel on big clone
        if (clone100.GetComponent<objectController>().mouseOver)
        {
            //handle the mouse wheel for the big clone
            Vector3 translateVec = clone100.transform.position - camera100.transform.position;
            if (Input.GetAxis("Mouse ScrollWheel") < 0)
            {
                Vector3 newPos = clone100.transform.position;
                if ((clone100.transform.position.z - camera100.transform.position.z) > distMin100)
                {
                   
                    translateVec = camera100.transform.forward * Input.GetAxis("Mouse ScrollWheel") * 100;
                    clone100.transform.position = newPos + translateVec;

                    //CLONE1
                    //transformation matrix
                    scale = new Vector3(0.01f, 0.01f, 0.01f);
                    transformation = Matrix4x4.Scale(scale);
                    translateVec = transformation * translateVec;
                    Vector3 translateVecToVehicle = camera1.transform.forward * translateVec.magnitude;
                    //do the translation
                    //clone1.transform.position = new Vector3(clone1.transform.position.x, clone1.transform.position.y, clone1.transform.position.z + translateVec.z);
                    clone1.transform.position -= translateVecToVehicle;
                }
            }
            else if (Input.GetAxis("Mouse ScrollWheel") > 0)
            {
                Vector3 newPos = clone100.transform.position;
                if ((clone100.transform.position.z - camera100.transform.position.z) < distMax100)
                { 
                    translateVec = camera100.transform.forward * Input.GetAxis("Mouse ScrollWheel") * 100;
                    clone100.transform.position = newPos + translateVec;
                    //CLONE1
                    //transformation matrix
                    scale = new Vector3(0.01f, 0.01f, 0.01f);
                    transformation = Matrix4x4.Scale(scale);
                    translateVec = transformation * translateVec;
                    Vector3 translateVecToVehicle = camera1.transform.forward * translateVec.magnitude;
                    //do the translation
                    //clone1.transform.position = new Vector3(clone1.transform.position.x, clone1.transform.position.y, clone1.transform.position.z + translateVec.z);
                    clone1.transform.position += translateVecToVehicle;
                }
            }

        }
    }
}
