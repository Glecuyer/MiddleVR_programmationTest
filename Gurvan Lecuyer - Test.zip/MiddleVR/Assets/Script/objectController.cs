﻿using UnityEngine;
using System.Collections;

public class objectController : MonoBehaviour
{
    //Rotation
    public bool isClicked;
    public bool mouseOver;

    public Vector3 mouseDown;

    void Start()
    {
        isClicked = false;
        mouseOver = false;
    }

    void OnMouseOver()
    {
        mouseOver = true;
    }

    void OnMouseExit()
    {
        mouseOver = false;
    }

    //Detect if the mouse clicked the object
    void OnMouseDown()
    {
        isClicked = true;
        mouseDown = Input.mousePosition;
    }

    //reinitialize the clicked bool
    void OnMouseUp()
    {
        isClicked = false;
    }
}
