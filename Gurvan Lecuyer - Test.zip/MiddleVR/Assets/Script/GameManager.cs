﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public Transform vehicle;
    private GameObject[] cubes;

    public Material Blue;
    public Material Red;

    public int nbRepere = 100;
    public GameObject reperePrefab;

    // Use this for initialization
    void Start()
    {
        vehicle = GameObject.FindGameObjectWithTag("Player").transform;

        cubes = new GameObject[nbRepere];
        Vector3 pos;
        for (int i = 0; i < nbRepere; i++)
        {
            pos = new Vector3(Random.Range(-100, 100), 0.1f, Random.Range(-100, 100));
            GameObject repere = (GameObject)Instantiate(reperePrefab, pos, Quaternion.identity);
            changeMaterial(repere);
            cubes[i] = repere;
        }
    }



    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < nbRepere; i++)
        {
            changeMaterial(cubes[i]);
        }
    }

    /// <summary>
    /// Function that change the material of the gameobject cube depending of the position off the vehicle
    /// </summary>
    /// <param name="ob">the GameObject to modify</param>
    private void changeMaterial(GameObject ob)
    {
        Vector3 vecToCenter = vehicle.position - ob.transform.position;
        //if > 0 ob is on the right of the vehicle, else is on is left
        //On the right so blue
        if (Vector3.Dot(vecToCenter, vehicle.right) > 0)
        {
            ob.GetComponent<Renderer>().material = Blue;
        }
        //On the left so red
        else
        {
            ob.GetComponent<Renderer>().material = Red;
        }
    }
}
