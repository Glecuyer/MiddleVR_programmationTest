﻿using UnityEngine;
using System.Collections;

public class grabController : MonoBehaviour
{
    public GameObject vehicle;

    void OnMouseDown()
    {
        vehicle.GetComponent<Controller>().clickDownPos = Input.mousePosition;
        vehicle.GetComponent<Controller>().click = true;
    }
}
