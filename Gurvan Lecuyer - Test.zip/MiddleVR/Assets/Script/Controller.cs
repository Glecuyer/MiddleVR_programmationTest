﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour
{

    public Vector3 clickDownPos;
    private Vector3 clickUpPos;
    public bool click;
    public Vector3 velocity;

    public float rotateSpeed;
    public float SpeedMax;
    public float speed;
    private float timer;
    private bool change;
    CharacterController charControl;
    //Camera Transform
    private Transform cameraTransform;

    // Use this for initialization
    void Start()
    {
        charControl = GetComponent<CharacterController>();

        cameraTransform = Camera.main.transform;

        click = false;
        change = false;

        velocity = Vector3.zero;
        clickDownPos = Vector3.zero;
        clickUpPos = Vector3.zero;

        speed = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (speed > 0)
        {
            if (timer > 0.5)
            {
                speed -= 3f;
                timer = 0;
            }
            else
            {
                timer += Time.deltaTime;
            }
        }
        else if(speed < 0)
        {
            speed = 0;
        }
        updateVelocity();
        //if the user give a new direction we had to the velocity vector of the vehicle the new velocity
        if (change)
        {
            change = false;
            //Reinitialize the timer to 0, speed to 10 and add the velocity
            timer = 0;
            speed = SpeedMax;

            velocity = clickDownPos - clickUpPos;
            velocity.z = velocity.y;
            velocity.y = 0;
            velocity.Normalize();
            float angle = Vector3.Angle(velocity, Vector3.forward);
            Vector3 cross = Vector3.Cross(velocity, Vector3.forward); 
            if (cross.y > 0)
            {
                angle = -angle;
            }
            velocity = Quaternion.Euler(0, angle, 0) * cameraTransform.forward;
            if (velocity != Vector3.zero)
            {
                charControl.Move(velocity * speed * Time.deltaTime);
                transform.position = new Vector3(transform.position.x, 0.26f, transform.position.z);
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.LookRotation(velocity), Time.deltaTime * rotateSpeed);
            }
        }
        else
        {
            if (velocity != Vector3.zero)
            {
                charControl.Move(velocity * speed * Time.deltaTime);
                transform.position = new Vector3(transform.position.x, 0.26f, transform.position.z);
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(velocity), Time.deltaTime * rotateSpeed);
            }
        }
    }

    /// <summary>
    /// updateVelocity check the event mouseUp, if detected a new vector velocity is calculated and the velocity vector of our controller is updated else we wait
    /// </summary>
    /// <returns></returns>
    void updateVelocity()
    {
        if (Input.GetMouseButtonUp(0))
        {
            if (click)
            {
                click = false;
                clickUpPos = Input.mousePosition;
                change = true;
            }
        }
    }
}
